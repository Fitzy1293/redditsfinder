from .meat import *

if __name__=='__main__':
    main()
